var carouselCtrlFn = function ($scope, $rootScope) {
	var mCtrl = this;
}
mainApp.controller('carouselCtrl', ['$scope', '$rootScope', carouselCtrlFn]);
